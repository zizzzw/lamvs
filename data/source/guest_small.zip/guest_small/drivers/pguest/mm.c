#include <linux/module.h>
#include <linux/pguest_mm.h>

static int mm_tunnel_match(struct device *dev, struct device_driver *drv);
static int mm_tunnel_probe(struct device *dev);
static int mm_tunnel_remove(struct device *dev);

static int tunnel_dev_probe(struct pci_dev *pdev,
			    const struct pci_device_id *ent);
static void tunnel_dev_remove(struct pci_dev *pdev);

struct pguest_mm_driver {
	struct pci_driver pci_driver;
	atomic_t dev_count;
};

struct bus_type mm_tunnel_bus_type = {
	.name = "pguest-mm-tunnel",
	.match = mm_tunnel_match,
	.probe = mm_tunnel_probe,
	.remove = mm_tunnel_remove,
};

static const struct pci_device_id pcidevtbl[] = {
	{ 0x0308, 0x0003, PCI_ANY_ID, PCI_ANY_ID },
	{ }
};

static struct pguest_mm_driver pguest_mm_driver = {
	.pci_driver = {
		.name = "pguest tunnel device driver",
		.id_table = pcidevtbl,
		.probe = tunnel_dev_probe,
		.remove = tunnel_dev_remove,
	},
	.dev_count = ATOMIC_INIT(0),
};

struct pguest_mm_tunnel_bus *
pguest_mm_tunnel_bus_get(struct pguest_mm_tunnel_bus *bus)
{
	if (bus)
		get_device(&bus->dev);
	return bus;
}
EXPORT_SYMBOL(pguest_mm_tunnel_bus_get);

void pguest_mm_tunnel_bus_put(struct pguest_mm_tunnel_bus *bus)
{
	if (bus)
		put_device(&bus->dev);
}
EXPORT_SYMBOL(pguest_mm_tunnel_bus_put);

struct pguest_mm_tunnel_dev *
pguest_mm_tunnel_get(struct pguest_mm_tunnel_dev *dev)
{
	if (dev)
		get_device(&dev->dev);
	return dev;
}
EXPORT_SYMBOL(pguest_mm_tunnel_get);

void pguest_mm_tunnel_put(struct pguest_mm_tunnel_dev *dev)
{
	if (dev)
		put_device(&dev->dev);
}
EXPORT_SYMBOL(pguest_mm_tunnel_put);

static void pguest_mm_tunnel_bus_remove_dev(struct pguest_mm_tunnel_bus *bus,
					    struct pguest_mm_tunnel_dev *dev)
{
	spin_lock(&bus->dev_lock);
	list_del_rcu(&dev->bus_list);
	spin_unlock(&bus->dev_lock);
}

static int mm_tunnel_match(struct device *dev, struct device_driver *driver)
{
	struct pguest_mm_tunnel_dev *tunnel = to_mm_tunnel_dev(dev);
	struct pguest_mm_tunnel_driver *tunnel_drv = to_mm_tunnel_drv(driver);
	return tunnel->type == tunnel_drv->type;
}

static int mm_tunnel_remove(struct device *dev)
{
	struct pguest_mm_tunnel_dev *tunnel = to_mm_tunnel_dev(dev);
	struct pguest_mm_tunnel_driver *drv = tunnel->drv;
	struct pguest_mm_tunnel_bus *bus;
	bus = pguest_mm_tunnel_get_parent_bus(tunnel);
	if (drv && drv->remove)
		drv->remove(tunnel);
	pguest_mm_tunnel_bus_remove_dev(bus, tunnel);
	pguest_mm_tunnel_put(tunnel);
	return 0;
}

static int mm_tunnel_probe(struct device *dev)
{
	int r;
	struct pguest_mm_tunnel_dev *tunnel = to_mm_tunnel_dev(dev);
	struct pguest_mm_tunnel_driver *driver = to_mm_tunnel_drv(dev->driver);
	pguest_mm_tunnel_get(tunnel);
	tunnel->drv = driver;
	r = driver->probe(tunnel);
	if (r) {
		pguest_mm_tunnel_put(tunnel);
		tunnel->drv = NULL;
		return r;
	}
	return r;
}

static int __init pguest_mm_init(void)
{
	long r = bus_register(&mm_tunnel_bus_type);
	if (r)
		return r;
	r = pci_register_driver(&pguest_mm_driver.pci_driver);
	if (r) {
		bus_unregister(&mm_tunnel_bus_type);
		return r;
	}
	return 0;
}

static void pguest_mm_dev_release(struct device *dev)
{
	struct pguest_mm_dev *mm = to_pguest_mm_dev(dev);
	pguest_mm_tunnel_bus_put(mm->bus);
	pci_iounmap(mm->pci_dev, mm->mmio);
	free_irq(mm->irq, mm);
	pci_free_irq_vectors(mm->pci_dev);
	kfree(mm);
}

static struct pguest_mm_tunnel_dev *
pguest_mm_dev_get_tunnel(struct pguest_mm_dev *dev, uint32_t index)
{
	struct pguest_mm_tunnel_bus *bus = dev->bus;
	struct pguest_mm_tunnel_dev *tunnel = NULL;
	rcu_read_lock();
	list_for_each_entry_rcu(tunnel, &bus->devices, bus_list) {
		if (tunnel->index == index) {
			pguest_mm_tunnel_get(tunnel);
			break;
		}
	}
	rcu_read_unlock();
	return tunnel;
}

static irqreturn_t mm_dev_irq_threaded_handler(int irq, void *dev_id)
{
	struct pguest_mm_dev *dev = dev_id;
	struct pguest_mm_tunnel_dev *tunnel;
	uint32_t irq_index, irq_status;
	irq_index = tunnel_dev_read32(dev, 0, MM_CONFIG_TUNNEL_IRQ_INDEX);
	irq_status = tunnel_dev_read32(dev, 0, MM_CONFIG_TUNNEL_IRQ_STATUS);
	tunnel = pguest_mm_dev_get_tunnel(dev, irq_index);
	if (!tunnel || !tunnel->drv || !tunnel->drv->irq_handler)
		goto out;
	tunnel->drv->irq_handler(tunnel, irq_status);
out:
	tunnel_dev_write32(dev, 0, MM_CONFIG_TUNNEL_IRQ_ACK, irq_status);
	pguest_mm_tunnel_put(tunnel);
	return IRQ_HANDLED;
}

static int pguest_mm_dev_alloc_irq(struct pguest_mm_dev *dev)
{
	int r = pci_set_dma_mask(dev->pci_dev, DMA_BIT_MASK(32));
	if (r)
		return r;
	pci_set_master(dev->pci_dev);
	r = pci_alloc_irq_vectors(dev->pci_dev, 1, 1, PCI_IRQ_ALL_TYPES);
	if (r < 1)
		return -ENOSPC;
	dev->irq = pci_irq_vector(dev->pci_dev, 0);
	r = request_threaded_irq(dev->irq, NULL,
				 mm_dev_irq_threaded_handler,
				 IRQF_SHARED | IRQF_ONESHOT,
				 "mm-tunnel-irq-handler", dev);
	if (r) {
		pci_free_irq_vectors(dev->pci_dev);
		dev->irq = 0;
	}
	return r;
}

static int pguest_mm_dev_init(struct pguest_mm_dev *dev,
			      struct pci_dev *pci_dev)
{
	void __iomem *mmio;
	spin_lock_init(&dev->tx_lock);
	dev->pci_dev = pci_dev;
	dev->dev.parent = &pci_dev->dev;
	dev->dev.release = pguest_mm_dev_release;
	dev->dev_no = atomic_inc_return(&pguest_mm_driver.dev_count);
	dev_set_name(&dev->dev, "tunnel-dev-%d", dev->dev_no);
	mmio = pci_iomap(pci_dev, 0, 0);
	if (!mmio)
		return -ENOMEM;
	dev->mmio = mmio;
	return pguest_mm_dev_alloc_irq(dev);
}

static void pguest_mm_tunnel_dev_release(struct device *dev)
{
	struct pguest_mm_tunnel_dev *tunnel = to_mm_tunnel_dev(dev);
	kfree(tunnel);
}

static void pguest_mm_tunnel_init(struct pguest_mm_tunnel_dev *dev,
				  struct pguest_mm_dev *mm, unsigned index)
{
	struct pguest_mm_tunnel_bus *bus = mm->bus;
	dev->dev.parent = &bus->dev;
	dev->dev.bus = &mm_tunnel_bus_type;
	dev->dev.release = pguest_mm_tunnel_dev_release;
	dev->index = index;
	dev->type = tunnel_read32(dev, MM_CONFIG_TUNNEL_FUNCTION);
	dev_set_name(&dev->dev, "tunnel-%d-%u", bus->bridge->dev_no, index);
}

static void pguest_mm_tunnel_bus_add_dev(struct pguest_mm_tunnel_bus *bus,
					 struct pguest_mm_tunnel_dev *dev)
{
	spin_lock(&bus->dev_lock);
	list_add_tail_rcu(&dev->bus_list, &bus->devices);
	spin_unlock(&bus->dev_lock);
}

static void pguest_mm_dev_alloc_tunnels(struct pguest_mm_dev *dev)
{
	uint32_t index_max;
	unsigned i;
	struct pguest_mm_tunnel_dev *tunnel;
	long r;
	index_max = tunnel_dev_read32(dev, 0, MM_CONFIG_TUNNEL_INDEX_MAX);
	tunnel_dev_write32(dev, 0, MM_CONFIG_TUNNEL_SETUP, 0);
	pr_info("initialize %u tunnels", index_max);
	for (i = 0; i < index_max; ++i) {
		tunnel = kzalloc(sizeof(*tunnel), GFP_KERNEL);
		pguest_mm_tunnel_init(tunnel, dev, i);
		r = device_register(&tunnel->dev);
		if (likely(!r)) {
			pguest_mm_tunnel_bus_add_dev(dev->bus, tunnel);
			continue;
		}
		pguest_mm_tunnel_put(tunnel);
		pr_warning("index %u initialize error with code %ld, ignoring",
			   i, r);
	}
}

static void pguest_mm_tunnel_bus_release(struct device *dev)
{
	struct pguest_mm_tunnel_bus *bus;
	bus = to_pguest_mm_tunnel_bus(dev);
	kfree(bus);
}

static struct pguest_mm_tunnel_bus *
pguest_mm_dev_create_bus(struct pguest_mm_dev *tunnel)
{
	struct pguest_mm_tunnel_bus *bus;
	bus = kzalloc(sizeof(*bus), GFP_KERNEL);
	if (!bus)
		return ERR_PTR(-ENOMEM);
	bus->bridge = tunnel;
	spin_lock_init(&bus->dev_lock);
	INIT_LIST_HEAD(&bus->devices);
	bus->dev.parent = &tunnel->dev;
	bus->dev.release = pguest_mm_tunnel_bus_release;
	dev_set_name(&bus->dev, "tunnel-bus");
	return bus;
}

static int tunnel_dev_probe(struct pci_dev *dev,
			    const struct pci_device_id *ent)
{
	long r;
	struct pguest_mm_dev *mm;
	struct pguest_mm_tunnel_bus *bus;
	r = pci_enable_device(dev);
	if (r)
		goto disable_dev;
	mm = kzalloc(sizeof(*mm), GFP_KERNEL);
	if (!mm)
		return -ENOMEM;
	r = pguest_mm_dev_init(mm, dev);
	if (r)
		goto free_mm;
	r = device_register(&mm->dev);
	if (r)
		goto free_dev;
	bus = pguest_mm_dev_create_bus(mm);
	if (IS_ERR(bus)) {
		r = PTR_ERR(bus);
		goto free_dev;
	}
	r = device_register(&bus->dev);
	if (r)
		goto free_bus;
	mm->bus = bus;
	pguest_mm_dev_alloc_tunnels(mm);
	pci_set_drvdata(dev, mm);
	return 0;
free_bus:
	pguest_mm_tunnel_bus_put(bus);
free_dev:
	put_device(&mm->dev);
free_mm:
	kfree(mm);
disable_dev:
	pci_disable_device(dev);
	return r;
}

int __pguest_mm_tunnel_register_driver(struct pguest_mm_tunnel_driver *drv,
				       struct module *module,
				       const char *name)
{
	drv->driver.name = drv->name;
	drv->driver.bus = &mm_tunnel_bus_type;
	drv->driver.owner = module;
	drv->driver.mod_name = name;

	/* register with core */
	return driver_register(&drv->driver);
}
EXPORT_SYMBOL(__pguest_mm_tunnel_register_driver);

void pguest_mm_tunnel_unregister_driver(struct pguest_mm_tunnel_driver *drv)
{
	driver_unregister(&drv->driver);
}
EXPORT_SYMBOL(pguest_mm_tunnel_unregister_driver);

static void tunnel_dev_remove(struct pci_dev *dev)
{
	struct pguest_mm_dev *mm = pci_get_drvdata(dev);
	if (unlikely(!mm))
		return;
	put_device(&mm->dev);
}

static void __exit pguest_mm_exit(void)
{
	bus_unregister(&mm_tunnel_bus_type);
	pci_unregister_driver(&pguest_mm_driver.pci_driver);
}

module_init(pguest_mm_init);
module_exit(pguest_mm_exit);
MODULE_DESCRIPTION("pguest share memory driver");
