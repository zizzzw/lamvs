#include <linux/pguestfs.h>
#include <linux/pguest_protocol.h>
#include <linux/pguest_mm.h>
#include <linux/pguest_ring.h>
#include <linux/hashtable.h>
#include <linux/uaccess.h>
#include <linux/wait.h>

#define TUNNEL_ERROR 0x1

struct pguestfs_user_data_transfer{
	wait_queue_head_t wait_queue;
	int wait_condition;
};

/* base.c */
extern const struct file_operations pguestfs_protocol_fops;

/* pguestfs_data_transfer.c */
struct pguestfs_data_transfer {
	struct pguest_mm_tunnel_dev *dev;
	spinlock_t lock;
	struct pguest_ring ring;
	int flags;
	struct ring_desc_cb ready_cb;
};

extern struct pguestfs_data_transfer *pguestfs_data_transfer;

/*
 * pguest data transfer api
 */
struct data_transfer_private_data {
	void *producer_private;
	void *consumer_private;
};

long pguestfs_subscribe(char *name, size_t size, SecurityLevel level, Action action);
long pguestfs_unsubscribe(const char *name, size_t size, SecurityLevel level);
long pguestfs_publish(char *name, size_t size, SecurityLevel level, Action action);
long pguestfs_unpublish(const char *name, size_t size, SecurityLevel level);
ssize_t send_out_protocol_read(struct file *filp, char __user *buffer,
			       size_t count, loff_t *ppos);
ssize_t send_out_protocol_write(struct file *filp, const char __user *buffer,
			        size_t count, loff_t *ppos);

/* protocol.c */
void* set_ready_protocol(void);
void* pguest_publish_protocol(const char *name, size_t size, 
			      SecurityLevel level, Action action);
void* pguest_unpublish_protocol(const char *name,size_t size,SecurityLevel level);
void* pguest_subscribe_protocol(const char *name, size_t size, 
				SecurityLevel level, Action action);
void* pguest_unsubscribe_protocol(const char *name, size_t size,SecurityLevel level);

void* pguestfs_read_data_protocol(struct protocol_header *info, size_t size, 
			     	  long offset);
void* pguestfs_read_info_protocol(struct protocol_header *info, size_t size, 
                                  long offset);
void* pguestfs_write_result_protocol(struct protocol_header *info, size_t size, 
                                     long offset);				  
void* pguestfs_write_data_protocol(struct protocol_header *info, size_t size, 
			      	   long offset);

/* pguestfs_accept_read.c */
void pguest_transfer_data_accept_read(void *opaque);

/* pguestfs_accept_write.c */
void pguest_transfer_data_accept_write(void *opaque);
