#include <linux/scatterlist.h>

#include "internal.h"

static ssize_t __write_process_after_communication(struct protocol_header *data,
					       	   loff_t *ppos)
{
	int ret = -EFAULT;
	switch(data->result){
	case PGUEST_SUCCESS:
		ret = data->data_length;
		*ppos += ret;
		break;
	case PGUEST_NOT_READY:
		pr_warning("busy, try again!\n");
		break;
	case PGUEST_RESOURCE_NONEXIST:
		pr_warning("error! resource do not exist!\n");
		return -EIO;
	case PGUEST_ERROR:
		pr_warning("error! write failed!\n");
		break;
	case PGUEST_PERMISSION_DENIED:
		pr_warning("error! you are refused by security policy!\n");
		return -EPERM;
	default:
		pr_warning("unexpected result, action: %d\n", data->action);
		break;
	}
	return ret;
}

static void __protocol_write_handle_data(struct pguest_ring *ring, void *opaque,
                                	 int64_t len)
{
	struct pguestfs_user_data_transfer *pudt = opaque;
	pudt->wait_condition = 1;
	wake_up_interruptible(&pudt->wait_queue);
}

ssize_t send_out_protocol_write(struct file *filp, const char __user *buffer,
			        size_t count, loff_t *ppos)
{
	int ret = -ENOMEM;
	struct protocol_header *file_info = filp->private_data;
	struct pguestfs_user_data_transfer *pudt = NULL;
	struct protocol_header *write_data = NULL;
	struct protocol_header *write_result = NULL;	
	struct ring_desc_cb cb = {
		.dequeue = __protocol_write_handle_data,
	};
	struct scatterlist sg[2];

	pudt = kzalloc(sizeof(*pudt), GFP_KERNEL);
	if (!pudt) {
		pr_warning("error! alloc memory for write file failed!\n");
		return -ENOMEM;
	}
	pudt->wait_condition = 0;
	init_waitqueue_head(&pudt->wait_queue);

	write_data = pguestfs_write_data_protocol(file_info, count, *ppos);
	if (!write_data) {
		pr_warning("alloc data package for write_probe failed!\n");
		goto free_write_data;
	}
	write_data->data = (void *)write_data + sizeof(*write_data) +
			   write_data->name_length;
	
	write_result = pguestfs_write_result_protocol(file_info, count, *ppos);
	if (!write_result) {
		pr_warning("alloc data package for write file failed!\n");
		goto free_write_result;
	}

	if (copy_from_user(write_data->data, buffer, count)){
		ret = -EFAULT;
                pr_warning("send_out_protocol_write copy_from_user failed!\n");
                goto free_data;
	}
	pr_info("write copy_from_user complete time: %llu\n",ktime_get_real_ns());
	
	cb.cb = pudt;
	sg_init_table(sg, 2);
	sg_set_buf(&sg[0], write_data, write_data->buf_length);
	sg_set_buf(&sg[1], write_result, write_result->buf_length);
	
	if(!pguest_ring_add_sg(&pguestfs_data_transfer->ring, sg, 1, 1, &cb))
		pguest_ring_notify(pguestfs_data_transfer->dev,
                                   &pguestfs_data_transfer->ring, 1);
	wait_event_interruptible(pudt->wait_queue, pudt->wait_condition == 1);

	/* wait */

	ret = __write_process_after_communication(write_result, ppos);
	pr_info("write data completed time: %llu\n",ktime_get_real_ns());
free_data:
	kfree(write_result);
free_write_result:
	kfree(write_data);
free_write_data:
	kfree(pudt);
	return ret;
}
