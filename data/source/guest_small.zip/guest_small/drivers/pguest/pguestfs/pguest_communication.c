#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/pguestfs_operations.h>

#include "internal.h"

#ifdef CONFIG_COMPAT
#define PGUEST_COMMUNICATION_COMPAT(func) .compat_ioctl = func
#else
static long pguest_communication_no_compat_ioctl(struct file *filp, 
                                                unsigned int ioctl,
				                unsigned long arg)
{
	return -EINVAL;
}
#define PGUEST_COMMUNICATION_COMPAT(func) \
        .compat_ioctl = pguest_communication_no_compat_ioctl
#endif

static long pguest_communication_ioctl(struct file *filp, unsigned int ioctl, 
                                       unsigned long arg)
{
        long r = -ENOMEM;
        struct pguestfs_object *object;
        struct protocol_header *header = NULL;
        char *name;

        object = memdup_user( (void __user *)arg, sizeof(*object));
	if (IS_ERR(object)){
                r = PTR_ERR(object);
		object = NULL;
		goto out;
        }
	name = memdup_user((void __user *)object->data, object->len + 1);
        name[object->len] = '\0';
	if (IS_ERR(name)) {
		kfree(object);
                r = PTR_ERR(name);
		goto out;
	}
        pr_info("filename:%s, security level is %d\n", name, 
                object->security_level);
        switch (ioctl) {
        case PGUESTFS_IOCTL_PUBLISH_READ:
                pr_info("PGUESTFS_IOCTL_PUBLISH_READ\n");
                r = pguestfs_publish(name, object->len + 1, object->security_level,
                                     PGUEST_PUBLISH_READ);
                break;
        case PGUESTFS_IOCTL_PUBLISH_WRITE:
                pr_info("PGUESTFS_IOCTL_PUBLISH_WRITE\n");
                r = pguestfs_publish(name, object->len + 1, object->security_level,
                                     PGUEST_PUBLISH_WRITE);
                break;
        case PGUESTFS_IOCTL_UNPUBLISH:
                pr_info("PGUESTFS_IOCTL_UNPUBLISH\n");
                r = pguestfs_unpublish(name, object->len + 1, object->security_level);
                break;
        case PGUESTFS_IOCTL_SUBSCRIBE_READ:
                pr_info("PGUESTFS_IOCTL_SUBSCRIBE_READ\n");
                r = pguestfs_subscribe(name, object->len + 1,object->security_level,
                                       PGUEST_SUBSCRIBE_READ);
                break;
        case PGUESTFS_IOCTL_SUBSCRIBE_WRITE:
                pr_info("PGUESTFS_IOCTL_SUBSCRIBE_WRITE\n");
                r = pguestfs_subscribe(name, object->len + 1,object->security_level,
                                       PGUEST_SUBSCRIBE_WRITE);
                break;
        case PGUESTFS_IOCTL_UNSUBSCRIBE:
                pr_info("PGUESTFS_IOCTL_UNSUBSCRIBE\n");
                header = filp->private_data;
                r = pguestfs_unsubscribe(name, object->len + 1,object->security_level);
                pguestfs_remove(header->data);
                kfree(header);
                break;
        }
        kfree(name);
        kfree(object);
out:
        return r;
}

static struct file_operations pguest_communication_ops = {
	.unlocked_ioctl = pguest_communication_ioctl,
	.llseek		= noop_llseek,
	PGUEST_COMMUNICATION_COMPAT(pguest_communication_ioctl),
	.owner		= THIS_MODULE,
};

static struct miscdevice pguest_communication_dev = {
	PGUEST_COMMUNICATION,
	"pguest_communication",
	&pguest_communication_ops,
};

static int __init init(void)
{
        int ret;
        ret = misc_register(&pguest_communication_dev);
        return ret;
}

static void __exit exit_communication(void)
{
        misc_deregister(&pguest_communication_dev);
}

module_init(init);
module_exit(exit_communication);
