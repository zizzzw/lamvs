#include <linux/scatterlist.h>

#include "internal.h"

static ssize_t __read_process_after_communication(struct protocol_header *data,
					      	  loff_t *ppos, 
						  char __user *buffer)
{
	int ret = -EFAULT;
	switch(data->result){
	case PGUEST_SUCCESS:
		data->data = (void *) data + sizeof(*data) + data->name_length;
		ret = copy_to_user(buffer, data->data, data->data_length);
		if (ret) {
			pr_warning("error! copy_to_user failed when read!\n");
		} else {
			*ppos += data->data_length;
			ret = data->data_length;
		}
		break;
	case PGUEST_NOT_READY:
		pr_warning("busy, try again!\n");
		break;
	case PGUEST_RESOURCE_NONEXIST:
		pr_warning("error! resource do not exist!\n");
		return -EIO;
	case PGUEST_ERROR:
		pr_warning("error! read from host failed!\n");
		break;
	case PGUEST_PERMISSION_DENIED:
		pr_warning("error! you are refused by security policy!\n");
		return -EPERM;
	default:
		pr_warning("unexpected result,action: %d\n", data->action);
		break;
	}
	return ret;
}

static void __protocol_read_handle_data(struct pguest_ring *ring, void *opaque,
                                      int64_t len)
{
	struct pguestfs_user_data_transfer *pudt = opaque;
	pudt->wait_condition = 1;
	wake_up_interruptible(&pudt->wait_queue);
}

ssize_t send_out_protocol_read(struct file *filp, char __user *buffer,
			       size_t count, loff_t *ppos)
{
	int ret = -ENOMEM;
	struct protocol_header *file_info = filp->private_data;
	struct pguestfs_user_data_transfer *pudt = NULL;
	struct protocol_header *read_info = NULL;
	struct protocol_header *read_data = NULL;		
	struct ring_desc_cb cb = {
		.dequeue = __protocol_read_handle_data,
	};
	struct scatterlist sg[2];

	pudt = kzalloc(sizeof(*pudt), GFP_KERNEL);
	if (!pudt) {
		pr_warning("alloc memory for read file failed!\n");
		return -ENOMEM;
	}
	pudt->wait_condition = 0;
	init_waitqueue_head(&pudt->wait_queue);

	read_info = pguestfs_read_info_protocol(file_info, count, *ppos);
	if (!read_info) {
		pr_warning("alloc data package for read_probe failed!\n");
		goto free_read_info;
	}

	read_data = pguestfs_read_data_protocol(file_info, count, *ppos);
	if (!read_data) {
		pr_warning("alloc data package for read file failed!\n");
		goto free_read_data;
	}

	cb.cb = pudt;
	sg_init_table(sg, 2);
	sg_set_buf(&sg[0], read_info, read_info->buf_length);
	sg_set_buf(&sg[1], read_data, read_data->buf_length);

	if(!pguest_ring_add_sg(&pguestfs_data_transfer->ring, sg, 1, 1, &cb))
		pguest_ring_notify(pguestfs_data_transfer->dev,
                                   &pguestfs_data_transfer->ring, 1);
	wait_event_interruptible(pudt->wait_queue, pudt->wait_condition == 1);

	/* wait */

	ret = __read_process_after_communication(read_data, ppos, buffer);
	pr_info("read data completed time: %llu\n",ktime_get_real_ns());
	kfree(read_data);
free_read_data:
	kfree(read_info);
free_read_info:
	kfree(pudt);
	return ret;
}
