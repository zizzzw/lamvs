#include <linux/uaccess.h>

#include "internal.h"

static ssize_t __pguest_vfs_read(void *opaque)
{
        struct file *filp;
        ssize_t ret = -EFAULT;
        mm_segment_t fs;
        struct protocol_header *header = opaque;

        header->name = opaque + sizeof(struct protocol_header);
        header->data = header->name + header->name_length;
        
        pr_info("filp_open %s in __pguest_vfs_read\n", header->name);
        filp = filp_open(header->name, O_RDONLY, 0);
        if (IS_ERR(filp)){
                pr_warning("filp_open file %s failed, %ld\n", header->name,
                           PTR_ERR(filp));
                return PTR_ERR(filp);
        }

        fs = get_fs();
        set_fs(KERNEL_DS);
        ret = vfs_read(filp, header->data, header->data_length, &header->offset);
        set_fs(fs);
        filp_close(filp, NULL);
        return ret;
}

static void __pguest_transfer_accept_read_free(struct pguest_ring *ring, 
                                               void *opaque)
{
	kfree(opaque);
}

void pguest_transfer_data_accept_read(void *opaque)
{
        struct protocol_header *in_header = opaque;
        long buf_length = sizeof(*in_header) + in_header->name_length + 
                          in_header->data_length;
        struct protocol_header *out_header = kzalloc(buf_length, GFP_KERNEL);
        struct ring_desc_cb cb = {
                .free = __pguest_transfer_accept_read_free,
        };
        ssize_t ret = 0;
        
        if(!out_header){
		pr_warning("alloc memory failed when pguest_transfer_data_accept_read");
		return;
	}
        memcpy(out_header, in_header, sizeof(struct protocol_header) + 
                                      in_header->name_length);
        out_header->action = PGUEST_ACCEPT_READ;
        out_header->buf_length = buf_length;
        out_header->name = (char *)out_header + sizeof(struct protocol_header);
        out_header->data = out_header->name + out_header->name_length;

        cb.cb = out_header;
        ret = __pguest_vfs_read(out_header);
        out_header->data_length = ret;
        if(ret < 0) {
                out_header->result = PGUEST_RESOURCE_NONEXIST;
        } else {
                out_header->result = PGUEST_SUCCESS;
        }
        
        if(!pguest_ring_add_buf(&pguestfs_data_transfer->ring, out_header, 
                            out_header->buf_length, false, &cb))
                pguest_ring_notify(pguestfs_data_transfer->dev,
                                   &pguestfs_data_transfer->ring, 1);
}
