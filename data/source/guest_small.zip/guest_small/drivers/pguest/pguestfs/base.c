#include <linux/pguestfs_operations.h>
#include <linux/fs.h>
#include <stdbool.h>

#include "internal.h"

#ifdef CONFIG_COMPAT
#define PGUESTFS_COMPAT(func) .compat_ioctl = func
#else
static long pguestfs_no_compat_ioctl(struct file *filp, unsigned int ioctl,
				     unsigned long arg)
{
	return -EINVAL;
}
#define PGUESTFS_COMPAT(func) .compat_ioctl = pguestfs_no_compat_ioctl
#endif

static ssize_t pguestfs_protocol_read(struct file *filp, char __user *buffer,
				      size_t count, loff_t *ppos)
{
	ssize_t ret = 0,tmp = 0;
	int turn = count / 4096;
	int i = 0;
	bool flag = true;

	pr_info("user read,count: %lu, ppos: %llu", count, *ppos);
	for(i = 0; i < turn; i++)
	{
		pr_info("read start time: %llu\n",ktime_get_real_ns());
		tmp = send_out_protocol_read(filp, buffer + i * 4096, 4096,
					     ppos);
		ret += tmp;
		if(tmp < 4096) {
			flag = false;
			break;
		}
	}
	if(flag) {
		tmp = send_out_protocol_read(filp, buffer + i * 4096,
					     count % 4096, ppos);
		ret += tmp;
	}
	return ret;
}

static ssize_t pguestfs_protocol_write(struct file *filp, 
				       const char __user *buffer,
				       size_t count, loff_t *ppos)
{
	ssize_t ret = 0,tmp = 0;
	int turn = count / 4096;
	int i = 0;
	bool flag = true;

	pr_info("user read,count: %lu, ppos: %llu", count, *ppos);
	for(i = 0; i < turn; i++)
	{
		pr_info("write start time: %llu\n",ktime_get_real_ns());
		tmp = send_out_protocol_write(filp, buffer + i * 4096, 4096,
					      ppos);
		ret += tmp;
		if(tmp < 4096) {
			flag = false;
			break;
		}
	}
	if(flag) {
		tmp = send_out_protocol_write(filp, buffer + i * 4096,
					      count % 4096, ppos);
		ret += tmp;
	}	
	return ret;
}

static int pguestfs_protocol_open(struct inode *inode, struct file *filp)
{
	filp->private_data = PGDE_DATA(inode);
	if (inode->i_mode & S_IWUSR) {
		if(filp->f_mode & FMODE_READ){
			pr_warning("this file is write only!\n");
			return -EPERM;
		}
	}

	if (inode->i_mode & S_IRUSR) {
		if(filp->f_mode & FMODE_WRITE){
			pr_warning("this file is read only!\n");
			return -EPERM;
		}	
	}
	return 0;
}

const struct file_operations pguestfs_protocol_fops = {
	.owner		= THIS_MODULE,
	.open		= pguestfs_protocol_open,
	.read		= pguestfs_protocol_read,
	.write		= pguestfs_protocol_write,
};
