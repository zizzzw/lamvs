#include <linux/uaccess.h>

#include "internal.h"

static ssize_t __pguest_vfs_write(void *opaque)
{
        struct file *filp;
        ssize_t ret = -EFAULT;
        mm_segment_t fs;
        struct protocol_header *header = opaque;

        header->name = opaque + sizeof(struct protocol_header);
        header->data = header->name + header->name_length;

        pr_info("filp_open %s in __pguest_vfs_write\n", header->name);
        filp = filp_open(header->name, O_WRONLY, 0);
        if (IS_ERR(filp)){
                pr_warning("filp_open file %s failed, %ld\n", header->name,
                           PTR_ERR(filp));
                return PTR_ERR(filp);
        }

        fs = get_fs();
        set_fs(KERNEL_DS);
        ret = vfs_write(filp, header->data, header->data_length, &header->offset);
        set_fs(fs);
        filp_close(filp, NULL);
        return 0;
}

static void __pguest_transfer_accept_write_handle_data(struct pguest_ring *ring, 
					               void *opaque, int64_t len)
{
        struct data_transfer_private_data *private_data = opaque;
        struct protocol_header *write_info = private_data->producer_private;
        if(write_info->result != PGUEST_RESOURCE_NONEXIST){
                __pguest_vfs_write(private_data->consumer_private);
        }
        
}

static void __pguest_transfer_accept_write_free(struct pguest_ring *ring, 
                                                void *opaque)
{
        struct data_transfer_private_data *private_data = opaque;
        kfree(private_data->producer_private);
        kfree(private_data->consumer_private);
	kfree(private_data);
}

void pguest_transfer_data_accept_write(void *opaque)
{
        struct protocol_header *in_header = opaque;
        long write_info_length = sizeof(*in_header) + in_header->name_length;
        long write_data_length = sizeof(*in_header) + in_header->name_length + 
                                 in_header->data_length;
        struct data_transfer_private_data *private_data = NULL;
        struct protocol_header *write_info = NULL;
        struct protocol_header *write_data = NULL;
        struct scatterlist sg[2];
        struct ring_desc_cb cb = {
                .dequeue = __pguest_transfer_accept_write_handle_data,
                .free = __pguest_transfer_accept_write_free,
        };
        struct file *filp;

        private_data = kzalloc(sizeof(*private_data), GFP_KERNEL);
        if(!private_data){
                pr_warning("alloc private_data failed when pguest_transfer_data_accept_write");
		return;
        }

        write_info = kzalloc(write_info_length, GFP_KERNEL);
        if(!write_info){
		pr_warning("alloc write_info failed when pguest_transfer_data_accept_write");
		goto free_write_info;
	}
        memcpy(write_info, in_header, write_info_length);

        filp = filp_open(write_info->name, O_RDONLY, 0);
        if (IS_ERR(filp)){
                pr_warning("filp_open file %s failed, %ld\n", write_info->name,
                           PTR_ERR(filp));
                write_info->result = PGUEST_RESOURCE_NONEXIST;
        }

        write_info->action = PGUEST_ACCEPT_WRITE;
        write_info->buf_length = write_info_length;
        write_info->name = (char *)write_info + sizeof(struct protocol_header);
        write_info->data = write_info->name + write_info->name_length;

        write_data = kzalloc(write_data_length, GFP_KERNEL);
        if(!write_data){
		pr_warning("alloc write_data failed when pguest_transfer_data_accept_write");
                goto free_write_data;
	}
        memcpy(write_data, write_info, write_info_length);
        write_data->buf_length = write_data_length;
        write_data->name = (char *)write_data + sizeof(struct protocol_header);
        write_data->data = write_data->name + write_data->name_length;

        sg_init_table(sg, 2);
        private_data->producer_private = write_info;
        private_data->consumer_private = write_data;
        cb.cb = private_data;

        pr_info("send out accept_write data package\n");
	sg_set_buf(&sg[0], write_info, write_info->buf_length);
	sg_set_buf(&sg[1], write_data, write_data->buf_length);
        if(!pguest_ring_add_sg(&pguestfs_data_transfer->ring, sg, 1, 1, &cb))
                pguest_ring_notify(pguestfs_data_transfer->dev,
                                   &pguestfs_data_transfer->ring, 1);
        return;
free_write_data:
        kfree(write_info);
free_write_info:
        kfree(private_data);
}
