#include <linux/module.h>
#include <stdbool.h>
#include <linux/wait.h>
#include <linux/rculist.h>

#include "internal.h"

struct pguestfs_data_transfer *pguestfs_data_transfer;

static void pguest_transfer_data(void *opaque)
{
        struct protocol_header *in_header = opaque;

        switch (in_header->action) {
        case PGUEST_READ:
                pguest_transfer_data_accept_read(opaque);
                break;
        case PGUEST_WRITE:
                pguest_transfer_data_accept_write(opaque);
                break;
        default:
                pr_warning("unexpected result, action: %d\n", in_header->action);
                break;
        }	
}

static void __ready_cb_handle_data(struct pguest_ring *ring, void *opaque,
                                   int64_t len)
{
	struct protocol_header *header = opaque;
        struct protocol_header *data_copy = kzalloc(header->buf_length, GFP_KERNEL);
	BUG_ON(len != 1);

        if(!data_copy) {
                pr_warning("alloc memory failed when __ready_cb_handle_data");
                return;
        }
        memcpy(data_copy, opaque, header->buf_length);

        data_copy->name = opaque + sizeof(struct protocol_header);
        data_copy->data = data_copy->name + data_copy->name_length;

        header->action = PGUEST_READY;
        if(!pguest_ring_add_buf(&pguestfs_data_transfer->ring,
                                pguestfs_data_transfer->ready_cb.cb, PAGE_SIZE,
                                true, &pguestfs_data_transfer->ready_cb))
	        pguest_ring_notify(pguestfs_data_transfer->dev,
                                   &pguestfs_data_transfer->ring, 1);

        pguest_transfer_data(data_copy);
        kfree(data_copy);
}

static int pguestfs_data_transfer_probe(struct pguest_mm_tunnel_dev *dev)
{
	int r = -ENOMEM;
	struct pguestfs_data_transfer *pdt = kzalloc(sizeof(*pdt), GFP_KERNEL);
	if (!pdt)
		return r;
        pguestfs_data_transfer = pdt;
	spin_lock_init(&pdt->lock);
	pdt->dev = dev;
	r = pguest_ring_alloc(dev, &pdt->ring);
        pdt->ready_cb.cb = set_ready_protocol();
	if (r || !pdt->ready_cb.cb)
		goto free_pfs;
	dev_set_drvdata(&dev->dev, pdt);
        
        pdt->ready_cb.dequeue = __ready_cb_handle_data;
        if(!pguest_ring_add_buf(&pdt->ring, pdt->ready_cb.cb, PAGE_SIZE, true, 
                                &pdt->ready_cb))
	        pguest_ring_notify(pdt->dev, &pdt->ring, 1);
	return 0;
free_pfs:
	kfree(pdt);
	return r;
}

static void pguestfs_data_transfer_remove(struct pguest_mm_tunnel_dev *dev)
{
	struct pguestfs_data_transfer *pdt = dev_get_drvdata(&dev->dev);
        kfree(pdt->ready_cb.cb);
	pguest_ring_destroy(pdt->dev, &pdt->ring);
	kfree(pdt);
	dev_set_drvdata(&dev->dev, NULL);
}

static void pguestfs_data_transfer_handle_error(struct pguest_mm_tunnel_dev *dev)
{
	struct pguestfs_data_transfer *pdt = dev_get_drvdata(&dev->dev);
	uint32_t error = tunnel_read32(dev, MM_CONFIG_TUNNEL_ERROR);
	if (error)
		pdt->flags |= TUNNEL_ERROR;
}

static void pguestfs_data_transfer_handle_data(struct pguest_mm_tunnel_dev *dev)
{
	struct pguestfs_data_transfer *pdt = dev_get_drvdata(&dev->dev);
	pguest_ring_dequeue(&pdt->ring);
}

static void pguestfs_data_transfer_irq_handler(struct pguest_mm_tunnel_dev *dev,
					       uint32_t irq_status)
{
	switch (irq_status) {
	case MM_INT_ERROR:
		pguestfs_data_transfer_handle_error(dev);
		break;
	case MM_INT_DATA_HANDLED:
		pguestfs_data_transfer_handle_data(dev);
		break;
	default:
		pr_warning("unknown irq status %#x", irq_status);
	}
}

static struct pguest_mm_tunnel_driver pguestfs_data_transfer_driver = {
	.name = "pguestfs_data_transfer_driver",
	.type = PGUESTFS_DATA_TRANSFER,
	.probe = pguestfs_data_transfer_probe,
	.remove = pguestfs_data_transfer_remove,
	.irq_handler = pguestfs_data_transfer_irq_handler,
};

static int __init pguestfs_data_transfer_init(void)
{
	return pguest_mm_tunnel_register_driver(&pguestfs_data_transfer_driver);
}

static void __exit pguestfs_data_transfer_exit(void)
{
	pguest_mm_tunnel_unregister_driver(&pguestfs_data_transfer_driver);
}

module_init(pguestfs_data_transfer_init);
module_exit(pguestfs_data_transfer_exit);
